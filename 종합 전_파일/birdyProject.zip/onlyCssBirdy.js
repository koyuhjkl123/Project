// 상단으로 이동 버튼 생성 및 스타일 설정
const scrollToTopBtn = document.createElement('button');
scrollToTopBtn.textContent = '↑';
scrollToTopBtn.style.position = 'fixed';
scrollToTopBtn.style.bottom = '20px';
scrollToTopBtn.style.right = '20px';
scrollToTopBtn.style.padding = '10px 15px';
scrollToTopBtn.style.fontSize = '20px';
scrollToTopBtn.style.display = 'none'; // 기본적으로 숨김
scrollToTopBtn.style.cursor = 'pointer';
document.body.appendChild(scrollToTopBtn);

// 스크롤 이벤트 리스너 추가
window.addEventListener('scroll', () => {
    if (window.pageYOffset > 100) {
        // 사용자가 100px 이상 스크롤하면 버튼 표시
        scrollToTopBtn.style.display = 'block';
    } else {
        scrollToTopBtn.style.display = 'none';
    }
});

// 버튼 클릭 시 상단으로 스무스 스크롤
scrollToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth',
    });
});

document.querySelectorAll('img').forEach(image => {
    image.addEventListener('click', () => {
        const lightbox = document.createElement('div');
        lightbox.id = 'lightbox';
        lightbox.style.position = 'fixed';
        lightbox.style.top = '0';
        lightbox.style.left = '0';
        lightbox.style.width = '100%';
        lightbox.style.height = '100%';
        lightbox.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
        lightbox.style.display = 'flex';
        lightbox.style.justifyContent = 'center';
        lightbox.style.alignItems = 'center';
        lightbox.style.zIndex = '1000';

        const img = document.createElement('img');
        img.src = image.src;
        img.style.maxWidth = '80%';
        img.style.maxHeight = '80%';
        lightbox.appendChild(img);

        document.body.appendChild(lightbox);

        lightbox.addEventListener('click', () => {
            document.body.removeChild(lightbox);
        });
    });
});

document.querySelectorAll('a[href="#"]').forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault(); // 기본 이벤트 차단
        const extraContent = this.parentNode.querySelector('.extra-content');
        if (extraContent) {
            extraContent.style.display = extraContent.style.display === 'none' ? 'block' : 'none'; // 내용 토글
        } else {
            // 추가 내용이 없을 경우, 간단한 메시지 표시
            alert('추가 정보가 준비되어 있지 않습니다.');
        }
    });
});

document.addEventListener('scroll', function () {
    var parallaxSpeed = 0.5;
    document.querySelectorAll('.parallax-section').forEach(function (section) {
        var offset = window.pageYOffset - section.offsetTop;
        section.style.backgroundPositionY = offset * parallaxSpeed + 'px';
    });
});
$(document).ready(function () {
    var $animation_elements = $('.slide');
    var $window = $(window);

    function check_if_in_view() {
        var window_height = $window.height();
        var window_top_position = $window.scrollTop();
        var window_bottom_position = window_top_position + window_height;

        $.each($animation_elements, function () {
            var $element = $(this);
            var element_height = $element.outerHeight();
            var element_top_position = $element.offset().top;
            var element_bottom_position = element_top_position + element_height;

            if (element_bottom_position >= window_top_position && element_top_position <= window_bottom_position) {
                $element.addClass('hasSlid');
            } else {
                $element.removeClass('hasSlid');
            }
        });
    }

    $window.on('scroll resize', check_if_in_view);
    $window.trigger('scroll');
});
