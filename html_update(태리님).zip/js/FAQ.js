function toggleInfo() {
  let infoBox = document.getElementById("infoBox");
  if (infoBox.style.display === "none") {
    infoBox.style.display = "block";
  } else {
    infoBox.style.display = "none";
  }
}